﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Orion.Api;

namespace OrionConnect_Api_Sample
{


    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private const string OrionConnectUrl = "https://testapi.orionadvisor.com/OrionConnectApp/integration.html";
        private void btnCheckToken_Click(object sender, EventArgs e) {

            try {

                if( OrionApi.SetToken( txtAuthToken.Text ) ) {
                    MessageBox.Show( "Token is valid!" );
                } else {
                    MessageBox.Show( "Token is not valid, you will need to login." );

                    var login = new frmLogin( );
                    if( login.ShowDialog( ) == DialogResult.OK ) {
                        OrionApi.Authenticate( login.UserName, login.Password );
                    }
                    txtAuthToken.Text = OrionApi.AuthToken;

                }
            } catch( Exception ex ) {
                MessageBox.Show( ex.Message );
            }
        }

        private void btnLaunchConnectMenu_Click(object sender, EventArgs e) {
            
            // add the auth token to the string, and launch the url, passing the auth token.
            Process.Start( string.Format( txtOrionConnectMenu.Text, OrionConnectUrl, OrionApi.AuthToken ) );

        }

        private void btnLaunchHHOverview_Click(object sender, EventArgs e)
        {

            //https://testapi.orionadvisor.com/OrionConnectApp/integration.html?p=/portfolio/household/overview%3Fentity%3D5%26entityId%3D{1}&t={0}

            /// url decoded, it looks like https://testapi.orionadvisor.com/OrionConnectApp/integration.html?p=/portfolio/household/overview?entity=5&entityId=46&t={0}
           

            // add the auth token and the household id to the string, and launch the url, passing the auth token.
            Process.Start(string.Format(txtHHOverview.Text, OrionConnectUrl, txtHouseholdId.Text, OrionApi.AuthToken));
        }
    }
}
