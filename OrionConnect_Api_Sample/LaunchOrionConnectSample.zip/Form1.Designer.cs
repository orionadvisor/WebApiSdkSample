﻿namespace OrionConnect_Api_Sample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCheckToken = new System.Windows.Forms.Button();
            this.txtAuthToken = new System.Windows.Forms.TextBox();
            this.txtOrionConnectMenu = new System.Windows.Forms.TextBox();
            this.txtHHOverview = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLaunchConnectMenu = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnLaunchHHOverview = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtHouseholdId = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCheckToken
            // 
            this.btnCheckToken.Location = new System.Drawing.Point(29, 50);
            this.btnCheckToken.Name = "btnCheckToken";
            this.btnCheckToken.Size = new System.Drawing.Size(137, 23);
            this.btnCheckToken.TabIndex = 0;
            this.btnCheckToken.Text = "Check Token";
            this.btnCheckToken.UseVisualStyleBackColor = true;
            this.btnCheckToken.Click += new System.EventHandler(this.btnCheckToken_Click);
            // 
            // txtAuthToken
            // 
            this.txtAuthToken.Location = new System.Drawing.Point(29, 24);
            this.txtAuthToken.Name = "txtAuthToken";
            this.txtAuthToken.Size = new System.Drawing.Size(586, 20);
            this.txtAuthToken.TabIndex = 1;
            this.txtAuthToken.Text = "<no token>";
            // 
            // txtOrionConnectMenu
            // 
            this.txtOrionConnectMenu.Location = new System.Drawing.Point(23, 165);
            this.txtOrionConnectMenu.Name = "txtOrionConnectMenu";
            this.txtOrionConnectMenu.Size = new System.Drawing.Size(479, 20);
            this.txtOrionConnectMenu.TabIndex = 2;
            this.txtOrionConnectMenu.Text = "{0}?p=/main&t={1}";
            // 
            // txtHHOverview
            // 
            this.txtHHOverview.Location = new System.Drawing.Point(23, 257);
            this.txtHHOverview.Name = "txtHHOverview";
            this.txtHHOverview.Size = new System.Drawing.Size(479, 20);
            this.txtHHOverview.TabIndex = 3;
            this.txtHHOverview.Text = "{0}?p=/portfolio/household/overview%3Fentity%3D5%26entityId%3D{1}&t={2}";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 149);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Orion Connect Main Menu";
            // 
            // btnLaunchConnectMenu
            // 
            this.btnLaunchConnectMenu.Location = new System.Drawing.Point(508, 165);
            this.btnLaunchConnectMenu.Name = "btnLaunchConnectMenu";
            this.btnLaunchConnectMenu.Size = new System.Drawing.Size(75, 23);
            this.btnLaunchConnectMenu.TabIndex = 5;
            this.btnLaunchConnectMenu.Text = "Launch";
            this.btnLaunchConnectMenu.UseVisualStyleBackColor = true;
            this.btnLaunchConnectMenu.Click += new System.EventHandler(this.btnLaunchConnectMenu_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 237);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Household Overview";
            // 
            // btnLaunchHHOverview
            // 
            this.btnLaunchHHOverview.Location = new System.Drawing.Point(508, 254);
            this.btnLaunchHHOverview.Name = "btnLaunchHHOverview";
            this.btnLaunchHHOverview.Size = new System.Drawing.Size(75, 23);
            this.btnLaunchHHOverview.TabIndex = 7;
            this.btnLaunchHHOverview.Text = "Launch";
            this.btnLaunchHHOverview.UseVisualStyleBackColor = true;
            this.btnLaunchHHOverview.Click += new System.EventHandler(this.btnLaunchHHOverview_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(295, 237);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Orion Household ID:";
            // 
            // txtHouseholdId
            // 
            this.txtHouseholdId.Location = new System.Drawing.Point(404, 234);
            this.txtHouseholdId.Name = "txtHouseholdId";
            this.txtHouseholdId.Size = new System.Drawing.Size(69, 20);
            this.txtHouseholdId.TabIndex = 9;
            this.txtHouseholdId.Text = "46";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(418, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "OrionConnect URL: https://testapi.orionadvisor.com/OrionConnectApp/integration.ht" +
    "ml";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 351);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtHouseholdId);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnLaunchHHOverview);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnLaunchConnectMenu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtHHOverview);
            this.Controls.Add(this.txtOrionConnectMenu);
            this.Controls.Add(this.txtAuthToken);
            this.Controls.Add(this.btnCheckToken);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCheckToken;
        private System.Windows.Forms.TextBox txtAuthToken;
        private System.Windows.Forms.TextBox txtOrionConnectMenu;
        private System.Windows.Forms.TextBox txtHHOverview;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLaunchConnectMenu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnLaunchHHOverview;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtHouseholdId;
        private System.Windows.Forms.Label label4;
    }
}

